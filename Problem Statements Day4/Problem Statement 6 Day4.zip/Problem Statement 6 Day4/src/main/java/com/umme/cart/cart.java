package com.umme.cart;

private SimpleMailMessage constructEmail(String subject, String body, 
		  User user) {
		    SimpleMailMessage email = new SimpleMailMessage();
		    email.setSubject(subject);
		    email.setText(body);
		    email.setTo(user.getEmail());
		    email.setFrom(env.getProperty("support.email"));
		    return email;
		}