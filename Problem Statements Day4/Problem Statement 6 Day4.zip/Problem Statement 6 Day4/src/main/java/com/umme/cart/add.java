package com.umme.cart;

private SimpleMailMessage constructResetTokenEmail(
		  String contextPath, Locale locale, String token, User user) {
		    String url = contextPath + "/user/changePassword?token=" + token;
		    String message = messages.getMessage("message.resetPassword", 
		      null, locale);
		    return constructEmail("Reset Password", message + " \r\n" + url, user);
		}
