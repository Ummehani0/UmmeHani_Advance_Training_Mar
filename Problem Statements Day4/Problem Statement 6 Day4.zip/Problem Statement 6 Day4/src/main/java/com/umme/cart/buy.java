package com.umme.cart;

public GenericResponse(String message, String error) {
    super();
    this.message = message;
    this.error = error;
}
}