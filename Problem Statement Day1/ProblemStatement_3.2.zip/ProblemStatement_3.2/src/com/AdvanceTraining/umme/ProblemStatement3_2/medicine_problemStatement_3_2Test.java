package com.AdvanceTraining.umme.ProblemStatement3_2;

public class medicine_problemStatement_3_2Test {
	public static void main(String[] args) 
	{
	medicine_problemStatement_3_2 Medicine_ProblemStatement_3_2[] = new medicine_problemStatement_3_2[5];
	double i = Math.random()*4;
	int j = (int) i;
	System.out.println(j);
	switch(j)
	{
	case 1: Medicine_ProblemStatement_3_2[0] = new medicine_problemStatement_3_2();

	Medicine_ProblemStatement_3_2[1] = new Tablet();
	Medicine_ProblemStatement_3_2[0].displayLabel();
	Medicine_ProblemStatement_3_2[1].displayLabel();
	break;
	case 2: Medicine_ProblemStatement_3_2[2] = new medicine_problemStatement_3_2();
	Medicine_ProblemStatement_3_2[3] = new Syrup();
	Medicine_ProblemStatement_3_2[2].displayLabel();
	Medicine_ProblemStatement_3_2[3].displayLabel();
	break;
	case 3: Medicine_ProblemStatement_3_2[4] = new medicine_problemStatement_3_2();
	Medicine_ProblemStatement_3_2[5] = new Ointment();
	Medicine_ProblemStatement_3_2[4].displayLabel();
	Medicine_ProblemStatement_3_2[5].displayLabel();
	break;
	default: System.out.println("Invalid Choice");
	}
	}
	}
