package com.AdvanceTraining.umme.ProblemStatement_3_1;

public class Instrument {
	public abstract void play();
	}
