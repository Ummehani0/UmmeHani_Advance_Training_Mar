package com.AdvanceTraining.umme.ProblemStatement_3_1;

public class Piano {
	@Override
	public void play() {
		System.out.println("Piano is playing  tan tan tan tan");

	}

}

