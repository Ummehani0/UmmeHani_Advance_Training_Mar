package com.AdvanceTraining.umme.ProblemStatement_8_1;

public class Working_On_ThreadCounter {

	public static void main(String args[])

	{

	Counter counter = new Counter(25);

	counter.run();

	}



	}
