package com.AdvanceTraining.umme.ProblemStatement_8_1;

import java.lang.Runnable;
public class Working_On_Storage {

	private int x;

	public Working_On_Storage(int X) { x=X; }

	public int GetX() { return(x); }



	public Working_On_Storage(Working_On_Storage s) { this.x = s.GetX(); }

	}



	class Printer implements Runnable

	{

	private Working_On_Storage working_On_Storage;



	Printer(Working_On_Storage s) { working_On_Storage = new Working_On_Storage(s); }



	public void run()

	{

	System.out.println(working_On_Storage.GetX());

	}



	}



	class Counter implements Runnable

	{

	private int N;



	public Counter(int n) { N=n; }

	public int GetN() { return(N); }



	public void run()

	{

	for (int iLoop=1; iLoop<=N; iLoop++)

	{

	Working_On_Storage working_On_Storage = new Working_On_Storage(iLoop);

	Printer printer = new Printer(working_On_Storage);

	Thread.yield();

	printer.run();

	}



	}



	}

