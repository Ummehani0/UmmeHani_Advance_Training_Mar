package com.AdvanceTraining.umme.ProblemStatement1_1;
import java.util.Scanner;
public class ProblemStatement_1_1 {
	 public static void main(String args[]) {

		  Scanner scan = new Scanner(System.in);
		  System.out.println("Enter the value : ");
		  
		  int num = scan.nextInt();

		  for (int i = 1; i <= num; i++) {

		   if (i % 2 == 0) {

		  System.out.print(i + " ");

		   }

		   }

		  }

		}

